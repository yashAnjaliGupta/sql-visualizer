v1- 
- update parser ts - add union funtionality
                   - re write the Function
                   - add types 
                   - position system
- update UI/UX 
- add dropdown for sql flavours