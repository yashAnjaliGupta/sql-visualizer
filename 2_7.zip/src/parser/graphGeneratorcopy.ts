import { table } from "console";
import { Parser } from "node-sql-parser";

interface GraphNode {
    id: string;
    type: string;
    [key: string]: any;
}

interface TableNode {
    id: string;
    type: string;
    data: { tableName: string; columns: { name: string; columnId: string }[] };
    position: { x: number; y: number };
}

interface GraphEdge {
    id: string;
    source: string;
    target: string;
    type: string;
    sourceHandle?: string;
    targetHandle?: string;
    label?: string | null;
}

interface Graph {
    nodes: GraphNode[];
    edges: GraphEdge[];
    tableNodes: { [key: string]: GraphNode };
    columnNodes: { [key: string]: GraphNode };
}

function assignPositionsWithTopologicalSort(
  nodes: TableNode[], 
  edges: { 
    id: string; 
    source: string; 
    target: string; 
    sourceHandle: string; 
    targetHandle: string; 
  }[]
): TableNode[] {
  const HORIZONTAL_SPACING = 400;
  const BASE_NODE_HEIGHT = 50;
  const HEIGHT_PER_COLUMN = 30;
  const VERTICAL_PADDING = 70;
  
  // Calculate approximate height for each node based on column count
  const calculateNodeHeight = (node: TableNode): number => {
    return BASE_NODE_HEIGHT + (node.data.columns.length * HEIGHT_PER_COLUMN);
  };
  
  // Build adjacency list from table relationships
  const graph: { [id: string]: string[] } = {};
  const inDegree: { [id: string]: number } = {};
  
  // Initialize graph and inDegree in one pass
  nodes.forEach(node => {
    graph[node.id] = [];
    inDegree[node.id] = 0;
  });
  
  // Process edges in a single pass
  edges.forEach(edge => {
    if (graph[edge.source] !== undefined && graph[edge.target] !== undefined) {
      graph[edge.target].push(edge.source);
      inDegree[edge.source]++;
    }
  });
  
  // Topological sort using Kahn's algorithm
  const queue: string[] = [];
  const layerMap: { [id: string]: number } = {};
  
  // Start with nodes having no incoming edges
  Object.keys(inDegree).forEach(nodeId => {
    if (inDegree[nodeId] === 0) {
      queue.push(nodeId);
      layerMap[nodeId] = 0;
    }
  });
  
  // Process the queue
  while (queue.length > 0) {
    const current = queue.shift()!;
    
    graph[current].forEach(neighbor => {
      inDegree[neighbor]--;
      
      if (inDegree[neighbor] === 0) {
        queue.push(neighbor);
        layerMap[neighbor] = layerMap[current] - 1;
      }
    });
  }
  
  // Handle cycles - assign unprocessed nodes to a new layer
  nodes.forEach(node => {
    if (layerMap[node.id] === undefined) {
      const maxLayer = Math.max(...Object.values(layerMap), 0);
      layerMap[node.id] = maxLayer + 1;
    }
  });
  
  // Group nodes by layer
  const layerGroups: { [layer: number]: TableNode[] } = {};
  nodes.forEach(node => {
    const layer = layerMap[node.id];
    if (!layerGroups[layer]) {
      layerGroups[layer] = [];
    }
    layerGroups[layer].push(node);
  });
  
  // Calculate node heights and layer heights in a single pass
  const layerHeights: { [layer: number]: number } = {};
  const layerNodeHeights: { [nodeId: string]: number } = {};
  const verticalPositions: { [id: string]: number } = {};
  
  Object.entries(layerGroups).forEach(([layer, layerNodes]) => {
    // Sort nodes by column count for better layout
    layerNodes.sort((a, b) => b.data.columns.length - a.data.columns.length);
    
    let totalLayerHeight = 0;
    const layerIndex = parseInt(layer);
    
    layerNodes.forEach(node => {
      const nodeHeight = calculateNodeHeight(node);
      layerNodeHeights[node.id] = nodeHeight;
      totalLayerHeight += nodeHeight + VERTICAL_PADDING;
    });
    
    // Subtract the last padding
    if (layerNodes.length > 0) {
      totalLayerHeight -= VERTICAL_PADDING;
    }
    
    layerHeights[layerIndex] = totalLayerHeight;
    
    // Calculate vertical positions immediately
    if (layerNodes.length === 1) {
      // Single node in layer - center it
      verticalPositions[layerNodes[0].id] = 0;
    } else {
      // Multiple nodes - distribute them
      let currentY = -totalLayerHeight / 2;
      layerNodes.forEach(node => {
        verticalPositions[node.id] = currentY;
        currentY += layerNodeHeights[node.id] + VERTICAL_PADDING;
      });
    }
  });
  
  // Update node positions based on their layer and calculated vertical position
  return nodes.map(node => ({
    ...node,
    position: {
      x: layerMap[node.id] * HORIZONTAL_SPACING,
      y: verticalPositions[node.id]
    }
  }));
}

export function codeToAst(code: string, database: string): any {
  const parser = new Parser();
  try {
    return parser.astify(code, { database: database });
  } catch (error) {
    return error;
  }
}

export function sqlAstToGraph(ast: any, graphID: number = 1): Graph {
  const graph: Graph = {
    nodes: [],
    edges: [],
    tableNodes: {},
    columnNodes: {},
  };
  
  // Maps to track column references
  const tableColumnsMap = new Map<string, Set<string>>();
  const nodeMap = new Map<string, GraphNode>();
  const edgeSet = new Set<string>();
  
  // Add alias mapping dictionary
  const aliasToTableMap = new Map<string, string>();
  
  const getActualTableName = (tableRef: string): string => {
    return aliasToTableMap.get(tableRef) || tableRef;
  };
  
  const createNode = (id: string, type: string, props: any): GraphNode => {
    // Check if node already exists
    if (nodeMap.has(id)) {
      return nodeMap.get(id)!;
    }
    
    // Create new node
    const node: GraphNode = { id, type, ...props };
    graph.nodes.push(node);
    nodeMap.set(id, node);
    
    // Add to appropriate collection - use real table name only
    if (type === 'table' || type === 'cte') {
      graph.tableNodes[props.name] = node;
      
      // Store alias mapping but don't use alias as key in tableNodes
      if (props.alias && props.alias !== props.name) {
        aliasToTableMap.set(props.alias, props.name);
      }
    } else if (type === 'column') {
      graph.columnNodes[id] = node;
    }
    
    return node;
  };
  
  const createEdge = (
    source: string, 
    target: string, 
    type: string, 
    sourceHandle?: string, 
    targetHandle?: string, 
    label: string | null = null
  ): GraphEdge | null => {
    // Skip self-loop edges
    if (source === target && sourceHandle && targetHandle && 
        sourceHandle === targetHandle) {
      return null;
    }
    
    const edgeId = `edge_${sourceHandle || source}_to_${targetHandle || target}_${type}`;
    
    // Check if edge already exists
    if (edgeSet.has(edgeId)) {
      return null;
    }
    
    const edge: GraphEdge = {
      id: edgeId,
      source,
      target,
      type,
      sourceHandle, 
      targetHandle,
      label
    };
    
    graph.edges.push(edge);
    edgeSet.add(edgeId);
    return edge;
  };
  
  const trackColumnReference = (tableName: string, columnName: string): void => {
    const realTableName = getActualTableName(tableName);
    if (!tableColumnsMap.has(realTableName)) {
      tableColumnsMap.set(realTableName, new Set<string>());
    }
    tableColumnsMap.get(realTableName)!.add(columnName);
  };
  
  const collectSourceColumns = (
    expr: any, 
    sourceColumns: { table: string; column: string }[]
  ): void => {
    if (!expr) return;
    
    switch (expr.type) {
      case 'column_ref':
        // If table reference is an alias, store it but resolve later
        sourceColumns.push({
          table: expr.table,
          column: expr.column
        });
        break;
        
      case 'function':
        if (expr.args && expr.args.value) {
          if (Array.isArray(expr.args.value)) {
            expr.args.value.forEach((arg: any) => 
              collectSourceColumns(arg, sourceColumns)
            );
          } else {
            collectSourceColumns(expr.args.value, sourceColumns);
          }
        }
        
        if (expr.over) {
          collectSourceColumns(expr.over, sourceColumns);
        }
        break;
        
      case 'binary_expr':
        collectSourceColumns(expr.left, sourceColumns);
        collectSourceColumns(expr.right, sourceColumns);
        break;
        
      case 'case':
        if (expr.expr) {
          collectSourceColumns(expr.expr, sourceColumns);
        }
        
        if (expr.args && Array.isArray(expr.args)) {
          expr.args.forEach((arg: any) => {
            if (arg.type === 'when') {
              collectSourceColumns(arg.cond, sourceColumns);
              collectSourceColumns(arg.result, sourceColumns);
            } else if (arg.type === 'else') {
              collectSourceColumns(arg.result, sourceColumns);
            }
          });
        }
        break;
        
      case 'aggr_func':
        if (expr.args && expr.args.expr) {
          collectSourceColumns(expr.args.expr, sourceColumns);
        }
        break;
    }
  };

  // Core AST processing function that handles all steps
  const processAST = (
    astNode: any, 
    currentGraphID: number, 
    isNestedQuery: boolean = false, 
    providedTableName?: string, 
    providedTableId?: string
  ): string => {
    if (!astNode) return '';
    
    // 1. Create result table node name for this AST level
    const resultTableId = providedTableId || 
      ((astNode._next === undefined && !isNestedQuery) 
        ? 'table_Result' 
        : `table_Result_0${currentGraphID}`);
        
    const resultName = providedTableName || 
      ((astNode._next === undefined && !isNestedQuery) 
        ? 'Result' 
        : `Result_0${currentGraphID}`);
    
    // 2. Process CTEs if present
    if (astNode.with && Array.isArray(astNode.with)) {
      astNode.with.forEach((cte: any) => {
        const cteName = cte.name.value;
        const cteId = `table_${cteName}`;
        
        // Create CTE node
        createNode(cteId, 'cte', {
          name: cteName,
          isCTE: true
        });
        
        // Process nested AST within CTE
        if (cte.stmt?.ast) {
          const nestedTable = processAST(
            cte.stmt.ast, 
            currentGraphID + 100, 
            true, 
            cteName, 
            cteId
          );
          
          // Link the nested result to this CTE
          if (nestedTable) {
            createEdge(nestedTable, cteId, 'table_TO_table');
          }
        }
      });
    }
    
    // 3. Create the result table node
    createNode(resultTableId, 'table', {
      name: resultName,
      setOperation: astNode.set_op || null
    });
    
    // 4. Process FROM tables/sources
    if (astNode.from) {
      astNode.from.forEach((tableItem: any) => {
        // Handle subqueries in FROM
        console.log('Processing table item:', tableItem);
        if (tableItem.expr) {
          const subqueryId = processAST(tableItem.expr.ast, currentGraphID + 1, true,tableItem.as, `table_${tableItem.as}`);
          // Link subquery to result
          if (subqueryId) {
            createEdge(
              subqueryId, 
              resultTableId, 
              'table_TO_table', 
              undefined, 
              undefined, 
              tableItem.as ? `${tableItem.as} → ${resultName}` : undefined
            );
          }
          return;
        }
        
        const tableName = tableItem.table;
        const tableAlias = tableItem.as;
        
        // Check if this is a reference to a CTE
        const cteNode = Object.values(graph.tableNodes).find(node => 
          node.isCTE === true && node.name === tableName
        );
        
        let tableId;
        
        if (cteNode) {
          // Use the existing CTE node ID
          tableId = cteNode.id;
        } else {
          // Regular table
          tableId = `table_${tableName}`;
          
          // Create table node - avoid using alias in the node ID
          createNode(tableId, 'table', {
            name: tableName,
            alias: tableAlias,
            db: tableItem.db
          });
        }
        
        // Add alias mapping
        if (tableAlias && tableAlias !== tableName) {
          aliasToTableMap.set(tableAlias, tableName);
        }
        
        // Link table to result
        createEdge(
          tableId, 
          resultTableId, 
          'table_TO_table', 
          undefined, 
          undefined, 
          tableAlias ? `${tableAlias} → ${resultName}` : `${tableName} → ${resultName}`
        );
      });
    }
    
    // 5. Process columns in SELECT clause
    if (astNode.columns) {
      const defaultSourceTable = astNode.from?.[0]?.table || null;
      
      astNode.columns.forEach((column: any) => {
        // Skip asterisk for now
        if (column.expr.type === 'star') return;
        
        let columnName: string;
        const sourceInfo: { table: string; column: string }[] = [];
        
        // Determine column name
        if (column.as) {
          columnName = column.as;
        } else if (column.expr.type === 'column_ref') {
          columnName = column.expr.column;
        } else {
          columnName = `expr_${Math.random().toString(36).substring(2, 7)}`;
        }
        
        // Create column node in result
        const columnId = `${resultName}_${columnName}`;
        createNode(columnId, 'column', {
          name: columnName,
          tableId: resultTableId,
          isCteColumn: resultTableId.includes('table_Result')
        });
        
        // Find source columns
        collectSourceColumns(column.expr, sourceInfo);
        
        // Create edges for all source columns
        sourceInfo.forEach(source => {
          if (!source.column) return;
          
          // Handle missing table reference
          if (!source.table && defaultSourceTable) {
            source.table = defaultSourceTable;
          }
          
          if (!source.table) return;
          
          // Resolve alias to actual table name
          const realTableName = getActualTableName(source.table);
          
          const sourceColumnId = `${realTableName}_${source.column}`;
          
          // Create source column if needed
          if (!graph.columnNodes[sourceColumnId]) {
            createNode(sourceColumnId, 'column', {
              name: source.column,
              tableId: `table_${realTableName}`
            });
            
            // Track this column reference
            trackColumnReference(realTableName, source.column);
          }
          
          // Create edge between columns - use real table names for IDs
          createEdge(
            `table_${realTableName}`, 
            resultTableId, 
            'column_mapping', 
            `source-${sourceColumnId}`, 
            `target-${columnId}`
          );
        });
      });
    }
    
    // //6. Process WHERE clause
    // if (astNode.where) {
    //   const processCondition = (condition: any) => {
    //     if (!condition) return;
        
    //     if (condition.type === 'column_ref') {
    //       const columnName = condition.column;
    //       let tableName = condition.table;
          
    //       // Resolve actual table name if this is an alias
    //       if (tableName) {
    //         // Get real table name from the alias map
    //         const realTableName = getActualTableName(tableName);
    //         trackColumnReference(realTableName, columnName);
            
    //         // Create condition edge
    //         const sourceColumnId = `${realTableName}_${columnName}`;
    //         createEdge(
    //           `table_${realTableName}`,
    //           resultTableId,
    //           'condition',  // Mark as condition type
    //           `source-${sourceColumnId}`,
    //           `target-${resultName}_condition`
    //         );
    //       } else if (astNode.from) {
    //         // If no table specified, check all FROM tables
    //         astNode.from.forEach((t: any) => {
    //           if (t.table) {
    //             const actualTable = t.table;
    //             trackColumnReference(actualTable, columnName);
                
    //             // Create condition edge
    //             const sourceColumnId = `${actualTable}_${columnName}`;
    //             createEdge(
    //               `table_${actualTable}`,
    //               resultTableId,
    //               'condition',  // Mark as condition type
    //               `source-${sourceColumnId}`,
    //               `target-${resultName}_condition`
    //             );
    //           }
    //         });
    //       }
    //     } else if (condition.type === 'binary_expr') {
    //       processCondition(condition.left);
    //       processCondition(condition.right);
    //     }
    //   };
      
    //   // Create a virtual condition node in the result table
    //   createNode(`${resultName}_condition`, 'condition', {
    //     name: 'WHERE condition',
    //     tableId: resultTableId
    //   });
      
    //   processCondition(astNode.where);
    // }
    
    // 7. Process JOIN conditions
    // astNode.from?.forEach((fromItem: any) => {
    //   if (fromItem.join) {
    //     const processJoinCondition = (condition: any) => {
    //       if (!condition) return;
          
    //       if (condition.type === 'binary_expr' && condition.operator === '=') {
    //         const leftColumn = condition.left.type === 'column_ref' ? condition.left : null;
    //         const rightColumn = condition.right.type === 'column_ref' ? condition.right : null;
            
    //         if (leftColumn && rightColumn) {
    //           // Resolve real table names from aliases
    //           let leftTableName = leftColumn.table;
    //           let rightTableName = rightColumn.table;
              
    //           // Resolve left table name if it's an alias
    //           if (leftTableName) {
    //             leftTableName = getActualTableName(leftTableName);
    //             trackColumnReference(leftTableName, leftColumn.column);
    //           }
              
    //           // Resolve right table name if it's an alias
    //           if (rightTableName) {
    //             rightTableName = getActualTableName(rightTableName);
    //             trackColumnReference(rightTableName, rightColumn.column);
    //           }
              
    //           // Create a connection between these columns using real table names
    //           if (leftTableName && rightTableName) {
    //             const leftColumnId = `${leftTableName}_${leftColumn.column}`;
    //             const rightColumnId = `${rightTableName}_${rightColumn.column}`;
                
    //             createEdge(
    //               `table_${leftTableName}`, 
    //               `table_${rightTableName}`, 
    //               'column_mapping', 
    //               `source-${leftColumnId}`, 
    //               `target-${rightColumnId}`
    //             );
    //           }
    //         }
    //       } else if (condition.type === 'binary_expr') {
    //         processJoinCondition(condition.left);
    //         processJoinCondition(condition.right);
    //       }
    //     };
        
    //     if (fromItem.on) {
    //       processJoinCondition(fromItem.on);
    //     }
    //   }
    // });
    
    // Handle nested queries (UNION, etc.) directly here
    if (astNode._next) {
      // Process the next AST part (e.g., after UNION)
      const nextPartId = processAST(
        astNode._next, 
        currentGraphID + 1, 
        true,
        providedTableName,
        providedTableId
      );
      console.log('Next part ID:', nextPartId);
      // Create a combined result node if this is the first part
      if (!isNestedQuery) {
        const combinedResultId = 'table_Result';
        const combinedResultName = 'Result';
        
        // Create combined result node
        createNode(combinedResultId, 'table', {
          name: combinedResultName,
          setOperation: astNode._next.set_op || null
        });
        
        // Link both parts to the combined result
        createEdge(resultTableId, combinedResultId, 'table_TO_table');
        createEdge(nextPartId, combinedResultId, 'table_TO_table');
        
        // Connect columns from both sides to the combined result
        // This could be enhanced to match columns by name/position
        const processColumns = (sourceId: string) => {
          graph.nodes
            .filter(node => node.type === 'column' && node.tableId === sourceId)
            .forEach(colNode => {
              const combinedColId = `${combinedResultName}_${colNode.name}`;
              
              // Create the column in combined result if needed
              if (!graph.columnNodes[combinedColId]) {
                createNode(combinedColId, 'column', {
                  name: colNode.name,
                  tableId: combinedResultId
                });
              }
              
              // Link source column to combined result column
              createEdge(
                sourceId,
                combinedResultId,
                'column_mapping',
                `source-${colNode.id}`,
                `target-${combinedColId}`
              );
            });
        };
        
        // Process columns from both sides of the UNION
        processColumns(resultTableId);
        processColumns(nextPartId);
        
        // Return the combined result for further processing
        return combinedResultId;
      }
    }
    
    return resultTableId;
  };
  
  // Process the main AST
  processAST(ast, graphID);
  
  // Create nodes for all tracked columns to ensure completeness
  tableColumnsMap.forEach((columns, tableName) => {
    const tableId = `table_${tableName}`;
    
    // Ensure table node exists - use real table name
    if (!graph.tableNodes[tableName]) {
      createNode(tableId, 'table', {
        name: tableName
      });
    }
    
    // Create column nodes
    columns.forEach(columnName => {
      const columnId = `${tableName}_${columnName}`;
      if (!graph.columnNodes[columnId]) {
        createNode(columnId, 'column', {
          name: columnName,
          tableId: tableId
        });
      }
    });
  });

  console.log('Graph generated with', graph.nodes, 'nodes and', graph.edges, 'edges');
  return graph;
}
export function getAllTableNodesAsTableNodes(graph: Graph): TableNode[] {
    // Use a Map to track unique table nodes by ID
    const uniqueNodes = new Map<string, TableNode>();
    
    // Process all table nodes and keep only unique ones
    Object.values(graph.tableNodes).forEach((node) => {
        // Skip if we already have this node
        if (uniqueNodes.has(node.id)) return;
        
        // Create a new TableNode and add it to our unique nodes
        uniqueNodes.set(node.id, {
            id: node.id,
            type: 'customTable',
            data: {
                tableName: node.name || '',
                columns: Object.values(graph.nodes)
                    .filter(colNode => colNode.tableId === node.id)
                    .map(colNode => ({
                        name: colNode.name,
                        columnId: colNode.id
                    }))
            },
            position: { x: 0, y: 0 }
        });
    });

    // Convert the map values to an array
    const nodes = Array.from(uniqueNodes.values());
    
    // Calculate positions
    const edges = getFilteredEdges(graph);
    return assignPositionsWithTopologicalSort(nodes, edges);
}
export function getFilteredEdges(graph: Graph): { 
  id: string; 
  source: string; 
  target: string; 
  sourceHandle: string; 
  targetHandle: string; 
}[] {
  return graph.edges
    .filter(edge => 
      edge.type === 'column_mapping' && 
      edge.sourceHandle && 
      edge.targetHandle
    )
    .map(edge => ({
      id: edge.id,
      source: edge.source,
      target: edge.target,
      sourceHandle: edge.sourceHandle as string,
      targetHandle: edge.targetHandle as string
    }));
}